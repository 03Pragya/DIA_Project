from pyspark.sql import SparkSession
from pyspark.ml.regression import LinearRegression
from pyspark.ml.feature import VectorAssembler
from pyspark.ml import Pipeline
from pyspark.sql.functions import col

# start a spark session
spark = SparkSession.builder.appName("LinearRegressionExample").getOrCreate()

# Assinging
# Features (X) are all columns except 'y_bool', which is the target variable (y)
X = df.drop('y_bool')

# labeling 
data = df.select(col("y_bool").alias("label"), *X.columns)

# Splitting 
train_data, test_data = data.randomSplit([0.8, 0.2], seed=42)

# Assembling all the features into a single vector column
feature_assembler = VectorAssembler(inputCols=X.columns, outputCol="features")

# Initializing model
lr = LinearRegression(featuresCol="features", labelCol="label")

# Creating a pipeline
pipeline = Pipeline(stages=[feature_assembler, lr])

# Training 
model = pipeline.fit(train_data)

# predictions 
predictions = model.transform(test_data)

# Evaluating 
mse = predictions.selectExpr("mean((label - prediction) * (label - prediction))").collect()[0][0]
r2 = model.stages[-1].summary.r2

# getting the regression coefficients and evaluation metrics
print("Regression Coefficients:")
print("Intercept:", model.stages[-1].intercept)
print("Coefficients:", model.stages[-1].coefficients)
print("\nEvaluation Metrics:")
print("Mean Squared Error:", mse)
print("R-squared:", r2)

# Stop Spark session
spark.stop()