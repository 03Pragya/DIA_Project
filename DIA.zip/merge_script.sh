#!/bin/bash

# datasets to HDFS
hadoop fs -put local_dataset1.csv /user/hadoop/dataset1.csv
hadoop fs -put local_dataset2.csv /user/hadoop/dataset2.csv

#  Mapper and Reducer
cat << 'EOF' > merge_script.py
#!/usr/bin/env python
import sys

current_key = None
current_data = []

for line in sys.stdin:
    line = line.strip()
    key, data = line.split('\t', 1)

    if key == current_key:
        current_data.append(data)
    else:
        if current_key:
            for d in current_data:
                print(f"{current_key}\t{d}")
        current_key = key
        current_data = [data]

# Output the last key
if current_key:
    for d in current_data:
        print(f"{current_key}\t{d}")
EOF

# Make the script executable
chmod +x merge_script.py

# Run Hadoop Streaming
hadoop jar $HADOOP_HOME/share/hadoop/tools/lib/hadoop-streaming*.jar \
-file merge_script.py -mapper merge_script.py \
-reducer merge_script.py \
-input /user/hadoop/dataset1.csv -input /user/hadoop/dataset2.csv \
-output /user/hadoop/merged_output

# Verify Results
hadoop fs -cat /user/hadoop/merged_output/part*

# Cleanup 
hadoop fs -rm /user/hadoop/dataset1.csv
hadoop fs -rm /user/hadoop/dataset2.csv
hadoop fs -rm -r /user/hadoop/merged_output